package com.example.keyviewer

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var preview: KeyboardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        preview = KeyboardView(this)

        val info = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            text = "1. Colok keyboard fisik (USB-OTG / Bluetooth).\n" +
                "2. Tekan tombol di bawah → Aksesibilitas → KeyViewer → aktifkan.\n" +
                "3. Overlay keyboard muncul di pojok kiri bawah layar, di atas game/aplikasi apa pun.\n\n" +
                "Preview di bawah ikut menyala kalau kamu menekan tombol (W, A, S, D, dll)."
        }

        val button = Button(this).apply {
            text = "Buka Pengaturan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.rgb(20, 20, 24))
            setPadding(pad, pad * 2, pad, pad)
            addView(info)
            addView(button)
            addView(preview, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = pad })
        })
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        when (event.action) {
            KeyEvent.ACTION_DOWN -> preview.setKey(event.keyCode, true)
            KeyEvent.ACTION_UP -> preview.setKey(event.keyCode, false)
        }
        return super.dispatchKeyEvent(event)
    }
}
