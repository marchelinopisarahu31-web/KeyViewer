package com.example.keyviewer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var preview: KeyboardView
    private val sp by lazy { Prefs.sp(this) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t
        setTextColor(Color.WHITE)
        textSize = 15f
        setPadding(0, dp(14), 0, dp(4))
    }

    private fun slider(title: String, key: String, min: Int, max: Int, def: Int, root: LinearLayout) {
        val tv = label("")
        fun refresh(v: Int) { tv.text = "$title: $v%" }
        val cur = sp.getInt(key, def).coerceIn(min, max)
        refresh(cur)
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = cur - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    refresh(v)
                    sp.edit().putInt(key, v).apply()
                    preview.applyPrefs(sp)
                }
                override fun onStartTrackingTouch(s: SeekBar?) = Unit
                override fun onStopTrackingTouch(s: SeekBar?) = Unit
            })
        }
        root.addView(tv)
        root.addView(sb)
    }

    private fun picker(title: String, key: String, names: List<String>, root: LinearLayout) {
        val b = Button(this)
        fun refresh() { b.text = "$title: ${names[sp.getInt(key, 0).coerceIn(0, names.size - 1)]}" }
        refresh()
        b.setOnClickListener {
            AlertDialog.Builder(this).setTitle(title)
                .setItems(names.toTypedArray()) { _, i ->
                    sp.edit().putInt(key, i).apply()
                    preview.applyPrefs(sp)
                    refresh()
                }.show()
        }
        root.addView(b)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preview = KeyboardView(this).also { it.applyPrefs(sp) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(24))
        }

        root.addView(TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f
            text = "1. Pairing keyboard/mouse (Bluetooth atau OTG).\n" +
                "2. Tekan tombol di bawah → Aksesibilitas → KeyViewer → aktifkan.\n" +
                "3. Atur tampilan di sini; overlay langsung ikut berubah.\n\n" +
                "Preview ikut menyala saat kamu tekan tombol / klik mouse."
        })
        root.addView(Switch(this).apply {
            text = "Overlay ON / OFF"
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(0, dp(12), 0, dp(12))
            isChecked = Prefs.isOn(this@MainActivity)
            setOnCheckedChangeListener { _, c -> Prefs.setOn(this@MainActivity, c) }
        })
        root.addView(TextView(this).apply {
            setTextColor(Color.LTGRAY); textSize = 12f
            text = "Pintasan lain: tombol KeyViewer di Quick Settings (panel notifikasi), " +
                "atau tekan CTRL + ALT + K di keyboard."
        })
        root.addView(Button(this).apply {
            text = "Buka Pengaturan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(preview, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16); gravity = Gravity.CENTER_HORIZONTAL })

        picker("Tema", Prefs.THEME, Themes.all.map { it.name }, root)
        picker("Layout", Prefs.LAYOUT, Prefs.layoutNames, root)
        slider("Ukuran", Prefs.SCALE, 40, 250, 100, root)
        slider("Transparansi (opacity)", Prefs.ALPHA, 20, 100, 100, root)
        slider("Posisi horizontal (kiri → kanan)", Prefs.POS_X, 0, 100, 0, root)
        slider("Posisi vertikal (atas → bawah)", Prefs.POS_Y, 0, 100, 92, root)
        root.addView(CheckBox(this).apply {
            text = "Tampilkan mouse"
            setTextColor(Color.WHITE)
            isChecked = sp.getBoolean(Prefs.SHOW_MOUSE, true)
            setOnCheckedChangeListener { _, c ->
                sp.edit().putBoolean(Prefs.SHOW_MOUSE, c).apply()
                preview.applyPrefs(sp)
            }
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.rgb(20, 20, 24))
            addView(root)
        })
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        when (event.action) {
            KeyEvent.ACTION_DOWN -> preview.setKey(event.keyCode, true)
            KeyEvent.ACTION_UP -> preview.setKey(event.keyCode, false)
        }
        return super.dispatchKeyEvent(event)
    }

    // Preview mouse saat app terbuka
    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_SCROLL) {
            val s = ev.getAxisValue(MotionEvent.AXIS_VSCROLL)
            if (s != 0f) preview.flashScroll(s > 0f)
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.source and android.view.InputDevice.SOURCE_MOUSE == android.view.InputDevice.SOURCE_MOUSE) {
            preview.setMouseButtons(
                if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) 0
                else ev.buttonState
            )
        }
        return super.dispatchTouchEvent(ev)
    }
}
