package com.example.keyviewer

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

class Theme(
    val name: String,
    val idle: Int,
    val pressed: Int,
    val stroke: Int,
    val text: Int,
    val pressedText: Int,
    val radiusDp: Float,
)

object Themes {
    val all = listOf(
        Theme("Classic", Color.argb(120, 60, 50, 45), Color.rgb(220, 30, 30),
            Color.argb(220, 225, 205, 180), Color.argb(230, 235, 215, 190), Color.WHITE, 3f),
        Theme("Neon", Color.argb(150, 10, 10, 35), Color.rgb(0, 255, 200),
            Color.rgb(255, 0, 200), Color.WHITE, Color.BLACK, 5f),
        Theme("Dark", Color.argb(160, 20, 20, 20), Color.rgb(235, 235, 235),
            Color.argb(200, 120, 120, 120), Color.argb(230, 220, 220, 220), Color.BLACK, 4f),
        Theme("Light", Color.argb(180, 245, 245, 245), Color.rgb(40, 120, 255),
            Color.rgb(90, 90, 90), Color.rgb(30, 30, 30), Color.WHITE, 4f),
        Theme("Pink", Color.argb(150, 60, 20, 50), Color.rgb(255, 80, 170),
            Color.rgb(255, 170, 220), Color.WHITE, Color.WHITE, 8f),
        Theme("Hacker", Color.argb(160, 0, 25, 0), Color.rgb(0, 230, 60),
            Color.rgb(0, 180, 50), Color.rgb(120, 255, 140), Color.BLACK, 1f),
        Theme("Biru", Color.argb(150, 10, 25, 60), Color.rgb(60, 140, 255),
            Color.rgb(120, 180, 255), Color.WHITE, Color.WHITE, 4f),
    )
}

object Prefs {
    const val THEME = "theme"
    const val SCALE = "scale"     // persen, 40..250
    const val ALPHA = "alpha"     // persen, 20..100
    const val LAYOUT = "layout"   // 0 full, 1 compact, 2 extended
    const val POS_X = "posx"      // persen 0..100
    const val POS_Y = "posy"      // persen 0..100
    const val SHOW_MOUSE = "mouse"
    const val ENABLED = "enabled" // tombol ON/OFF overlay

    fun isOn(c: Context) = sp(c).getBoolean(ENABLED, true)
    fun setOn(c: Context, on: Boolean) = sp(c).edit().putBoolean(ENABLED, on).apply()

    val layoutNames = listOf("Full (ESC-CTRL)", "Compact (QWER/ASDF)", "Extended (+F1-F5)")

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("kv", Context.MODE_PRIVATE)
}
