package com.example.keyviewer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.KeyEvent
import android.view.View

/** Menggambar keyboard mini (ESC/1-5, TAB/QWERT, CAPS/ASDFG, SHIFT/ZXCVB, CTRL/ALT/SPACE) + mouse. */
class KeyboardView(context: Context) : View(context) {

    private class Key(val label: String, val codes: IntArray, val weight: Float = 1f)

    private val rows: List<List<Key>> = listOf(
        listOf(
            Key("ESC", intArrayOf(KeyEvent.KEYCODE_ESCAPE)),
            Key("1", intArrayOf(KeyEvent.KEYCODE_1)),
            Key("2", intArrayOf(KeyEvent.KEYCODE_2)),
            Key("3", intArrayOf(KeyEvent.KEYCODE_3)),
            Key("4", intArrayOf(KeyEvent.KEYCODE_4)),
            Key("5", intArrayOf(KeyEvent.KEYCODE_5)),
        ),
        listOf(
            Key("TAB", intArrayOf(KeyEvent.KEYCODE_TAB)),
            Key("Q", intArrayOf(KeyEvent.KEYCODE_Q)),
            Key("W", intArrayOf(KeyEvent.KEYCODE_W)),
            Key("E", intArrayOf(KeyEvent.KEYCODE_E)),
            Key("R", intArrayOf(KeyEvent.KEYCODE_R)),
            Key("T", intArrayOf(KeyEvent.KEYCODE_T)),
        ),
        listOf(
            Key("CAPS", intArrayOf(KeyEvent.KEYCODE_CAPS_LOCK)),
            Key("A", intArrayOf(KeyEvent.KEYCODE_A)),
            Key("S", intArrayOf(KeyEvent.KEYCODE_S)),
            Key("D", intArrayOf(KeyEvent.KEYCODE_D)),
            Key("F", intArrayOf(KeyEvent.KEYCODE_F)),
            Key("G", intArrayOf(KeyEvent.KEYCODE_G)),
        ),
        listOf(
            Key("SHIFT", intArrayOf(KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT)),
            Key("Z", intArrayOf(KeyEvent.KEYCODE_Z)),
            Key("X", intArrayOf(KeyEvent.KEYCODE_X)),
            Key("C", intArrayOf(KeyEvent.KEYCODE_C)),
            Key("V", intArrayOf(KeyEvent.KEYCODE_V)),
            Key("B", intArrayOf(KeyEvent.KEYCODE_B)),
        ),
        listOf(
            Key("CTRL", intArrayOf(KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT)),
            Key("ALT", intArrayOf(KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT)),
            Key("SPACE", intArrayOf(KeyEvent.KEYCODE_SPACE), weight = 4f),
        ),
    )

    private val pressed = HashSet<Int>()

    private val idleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(120, 60, 50, 45) }
    private val pressedFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(220, 30, 30) }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 225, 205, 180)
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(230, 235, 215, 190)
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()

    private fun dp(v: Float) = v * resources.displayMetrics.density

    fun setKey(keyCode: Int, down: Boolean) {
        val changed = if (down) pressed.add(keyCode) else pressed.remove(keyCode)
        if (changed) postInvalidate()
    }

    fun clearKeys() {
        pressed.clear()
        postInvalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(dp(230f).toInt(), dp(120f).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val gap = dp(2.5f)
        val mouseW = dp(52f)
        val kbW = width - mouseW - dp(6f)
        val rowH = (height - gap * (rows.size - 1)) / rows.size

        rows.forEachIndexed { r, row ->
            val totalWeight = row.sumOf { it.weight.toDouble() }.toFloat()
            val unit = (kbW - gap * (row.size - 1)) / totalWeight
            var x = 0f
            val y = r * (rowH + gap)
            for (key in row) {
                val w = unit * key.weight
                rect.set(x, y, x + w, y + rowH)
                val isDown = key.codes.any { it in pressed }
                canvas.drawRoundRect(rect, dp(3f), dp(3f), if (isDown) pressedFill else idleFill)
                canvas.drawRoundRect(rect, dp(3f), dp(3f), stroke)
                text.textSize = if (key.label.length > 2) rowH * 0.34f else rowH * 0.46f
                val ty = rect.centerY() - (text.descent() + text.ascent()) / 2f
                canvas.drawText(key.label, rect.centerX(), ty, text)
                x += w + gap
            }
        }
        drawMouse(canvas, kbW + dp(6f), mouseW)
    }

    private fun drawMouse(canvas: Canvas, left: Float, w: Float) {
        rect.set(left, 0f, left + w, height.toFloat())
        canvas.drawRoundRect(rect, w * 0.4f, w * 0.4f, idleFill)
        canvas.drawRoundRect(rect, w * 0.4f, w * 0.4f, stroke)
        val splitY = height * 0.38f
        canvas.drawLine(rect.left, splitY, rect.right, splitY, stroke)
        canvas.drawLine(rect.centerX(), 0f, rect.centerX(), splitY, stroke)
        rect.set(rect.centerX() - dp(4f), splitY * 0.25f, rect.centerX() + dp(4f), splitY * 0.75f)
        canvas.drawRoundRect(rect, dp(4f), dp(4f), stroke)
    }
}
