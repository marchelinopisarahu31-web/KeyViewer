package com.example.keyviewer

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View

/** Overlay keyboard + mouse. Ukuran, tema, dan layout diatur lewat Prefs. */
class KeyboardView(context: Context) : View(context) {

    private class Key(val label: String, val codes: IntArray, val weight: Float = 1f)

    private fun k(c: String, w: Float = 1f) =
        Key(c, intArrayOf(KeyEvent.keyCodeFromString("KEYCODE_$c")), w)

    private fun rowsFor(layout: Int): List<List<Key>> {
        val esc = Key("ESC", intArrayOf(KeyEvent.KEYCODE_ESCAPE))
        val tab = Key("TAB", intArrayOf(KeyEvent.KEYCODE_TAB))
        val caps = Key("CAPS", intArrayOf(KeyEvent.KEYCODE_CAPS_LOCK))
        val shift = Key("SHIFT", intArrayOf(KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT))
        val ctrl = Key("CTRL", intArrayOf(KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT))
        val alt = Key("ALT", intArrayOf(KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT))
        fun space(w: Float) = Key("SPACE", intArrayOf(KeyEvent.KEYCODE_SPACE), w)

        val full = listOf(
            listOf(esc, k("1"), k("2"), k("3"), k("4"), k("5")),
            listOf(tab, k("Q"), k("W"), k("E"), k("R"), k("T")),
            listOf(caps, k("A"), k("S"), k("D"), k("F"), k("G")),
            listOf(shift, k("Z"), k("X"), k("C"), k("V"), k("B")),
            listOf(ctrl, alt, space(4f)),
        )
        return when (layout) {
            1 -> listOf(
                listOf(k("Q"), k("W"), k("E"), k("R")),
                listOf(k("A"), k("S"), k("D"), k("F")),
                listOf(shift, ctrl, space(2f)),
            )
            2 -> listOf(listOf(esc, k("F1"), k("F2"), k("F3"), k("F4"), k("F5"))) + full
            else -> full
        }
    }

    private var rows = rowsFor(0)
    private var theme = Themes.all[0]
    private var scale = 1f
    private var showMouse = true

    private val pressed = HashSet<Int>()
    private var left = false
    private var right = false
    private var middle = false
    private var scrollUp = false
    private var scrollDown = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()
    private val path = Path()

    private fun dp(v: Float) = v * resources.displayMetrics.density

    private val keyUnit get() = dp(30f)
    private val rowH get() = dp(22f)
    private val gap get() = dp(2.5f)
    private val mouseW get() = dp(54f)

    private val clearScroll = Runnable { scrollUp = false; scrollDown = false; invalidate() }

    fun applyPrefs(sp: SharedPreferences) {
        theme = Themes.all[sp.getInt(Prefs.THEME, 0).coerceIn(0, Themes.all.size - 1)]
        scale = sp.getInt(Prefs.SCALE, 100).coerceIn(40, 250) / 100f
        alpha = sp.getInt(Prefs.ALPHA, 100).coerceIn(20, 100) / 100f
        rows = rowsFor(sp.getInt(Prefs.LAYOUT, 0))
        showMouse = sp.getBoolean(Prefs.SHOW_MOUSE, true)
        requestLayout()
        invalidate()
    }

    fun setKey(keyCode: Int, down: Boolean) {
        val changed = if (down) pressed.add(keyCode) else pressed.remove(keyCode)
        if (changed) postInvalidate()
    }

    /** buttonState dari MotionEvent mouse. */
    fun setMouseButtons(state: Int) {
        left = state and MotionEvent.BUTTON_PRIMARY != 0
        right = state and MotionEvent.BUTTON_SECONDARY != 0
        middle = state and MotionEvent.BUTTON_TERTIARY != 0
        postInvalidate()
    }

    fun setRightClick(down: Boolean) {
        right = down
        postInvalidate()
    }

    fun flashScroll(up: Boolean) {
        scrollUp = up
        scrollDown = !up
        removeCallbacks(clearScroll)
        postDelayed(clearScroll, 150)
        postInvalidate()
    }

    fun clearAll() {
        pressed.clear()
        left = false; right = false; middle = false
        postInvalidate()
    }

    private fun baseKbW(): Float {
        val maxW = rows.maxOf { r -> r.sumOf { it.weight.toDouble() }.toFloat() }
        return maxW * keyUnit + gap * (rows.maxOf { it.size } - 1)
    }

    private fun baseW() = baseKbW() + if (showMouse) dp(6f) + mouseW else 0f
    private fun baseH() = maxOf(rows.size * rowH + gap * (rows.size - 1), dp(84f))

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension((baseW() * scale).toInt() + 1, (baseH() * scale).toInt() + 1)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.scale(scale, scale)
        stroke.color = theme.stroke
        stroke.strokeWidth = dp(1f)
        val radius = dp(theme.radiusDp)
        val kbW = baseKbW()
        val h = baseH()
        val rh = (h - gap * (rows.size - 1)) / rows.size

        rows.forEachIndexed { r, row ->
            val totalWeight = row.sumOf { it.weight.toDouble() }.toFloat()
            val unit = (kbW - gap * (row.size - 1)) / totalWeight
            var x = 0f
            val y = r * (rh + gap)
            for (key in row) {
                val w = unit * key.weight
                rect.set(x, y, x + w, y + rh)
                val down = key.codes.any { it in pressed }
                fill.color = if (down) theme.pressed else theme.idle
                canvas.drawRoundRect(rect, radius, radius, fill)
                canvas.drawRoundRect(rect, radius, radius, stroke)
                text.color = if (down) theme.pressedText else theme.text
                text.textSize = if (key.label.length > 2) rh * 0.36f else rh * 0.5f
                val ty = rect.centerY() - (text.descent() + text.ascent()) / 2f
                canvas.drawText(key.label, rect.centerX(), ty, text)
                x += w + gap
            }
        }
        if (showMouse) drawMouse(canvas, kbW + dp(6f), h)
    }

    private fun drawMouse(canvas: Canvas, x0: Float, h: Float) {
        val w = mouseW
        val body = RectF(x0, 0f, x0 + w, h)
        val corner = w * 0.42f
        val splitY = h * 0.40f
        val cx = body.centerX()

        // badan
        fill.color = theme.idle
        canvas.drawRoundRect(body, corner, corner, fill)

        // tombol kiri / kanan (diklip ke bentuk badan)
        path.reset()
        path.addRoundRect(body, corner, corner, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(path)
        fill.color = theme.pressed
        if (left) canvas.drawRect(body.left, 0f, cx, splitY, fill)
        if (right) canvas.drawRect(cx, 0f, body.right, splitY, fill)
        canvas.restore()

        canvas.drawRoundRect(body, corner, corner, stroke)
        canvas.drawLine(body.left, splitY, body.right, splitY, stroke)
        canvas.drawLine(cx, 0f, cx, splitY, stroke)

        // roda scroll: atas = scroll up, bawah = scroll down, isi penuh = klik tengah
        val ww = dp(9f)
        val wheel = RectF(cx - ww / 2, splitY * 0.18f, cx + ww / 2, splitY * 0.82f)
        fill.color = theme.pressed
        if (middle) canvas.drawRoundRect(wheel, dp(4f), dp(4f), fill)
        if (scrollUp) canvas.drawRect(wheel.left, wheel.top, wheel.right, wheel.centerY(), fill)
        if (scrollDown) canvas.drawRect(wheel.left, wheel.centerY(), wheel.right, wheel.bottom, fill)
        canvas.drawRoundRect(wheel, dp(4f), dp(4f), stroke)
    }
}
