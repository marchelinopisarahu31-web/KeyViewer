package com.example.keyviewer

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Accessibility service: menangkap keyboard & mouse fisik secara global
 * lalu menampilkannya di overlay. Event TIDAK dikonsumsi, jadi tetap sampai ke game
 * / app mapper (Panda Mouse Pro, K2ER, dll).
 */
class KeyOverlayService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {

    private var view: KeyboardView? = null
    private var params: WindowManager.LayoutParams? = null
    private var probe: View? = null          // fallback klik mouse untuk Android < 14
    private lateinit var wm: WindowManager

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // Android 14+: terima event mouse global lewat onMotionEvent
        if (Build.VERSION.SDK_INT >= 34) {
            serviceInfo = serviceInfo.apply { motionEventSources = InputDevice.SOURCE_MOUSE }
        }

        val v = KeyboardView(this)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        v.applyPrefs(Prefs.sp(this))
        wm.addView(v, p)
        view = v
        params = p
        relayout()
        applyEnabled()

        if (Build.VERSION.SDK_INT < 34) addProbe()

        Prefs.sp(this).registerOnSharedPreferenceChangeListener(this)
    }

    /** View 1x1 yang menangkap "touch di luar" supaya tombol mouse terbaca di Android < 14. */
    private fun addProbe() {
        val pv = View(this)
        pv.setOnTouchListener { _, e ->
            if (e.source and InputDevice.SOURCE_MOUSE == InputDevice.SOURCE_MOUSE) {
                view?.setMouseButtons(if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) e.buttonState else 0)
            }
            false
        }
        val lp = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(pv, lp)
        probe = pv
    }

    private fun relayout() {
        val v = view ?: return
        val p = params ?: return
        val sp = Prefs.sp(this)
        val dm = resources.displayMetrics
        v.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val px = sp.getInt(Prefs.POS_X, 0) / 100f
        val py = sp.getInt(Prefs.POS_Y, 92) / 100f
        p.x = ((dm.widthPixels - v.measuredWidth) * px).toInt().coerceAtLeast(0)
        p.y = ((dm.heightPixels - v.measuredHeight) * py).toInt().coerceAtLeast(0)
        wm.updateViewLayout(v, p)
    }

    private fun applyEnabled() {
        val on = Prefs.isOn(this)
        view?.visibility = if (on) View.VISIBLE else View.GONE
        probe?.visibility = if (on) View.VISIBLE else View.GONE
        if (!on) view?.clearAll()
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        val v = view ?: return
        v.applyPrefs(Prefs.sp(this))
        v.post { relayout() }
        applyEnabled()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // Hotkey ON/OFF: CTRL + ALT + K
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 &&
            event.keyCode == KeyEvent.KEYCODE_K && event.isCtrlPressed && event.isAltPressed
        ) {
            Prefs.setOn(this, !Prefs.isOn(this))
            return false
        }
        if (!Prefs.isOn(this)) return false

        val isMouse = event.source and InputDevice.SOURCE_MOUSE == InputDevice.SOURCE_MOUSE
        val down = event.action == KeyEvent.ACTION_DOWN
        val up = event.action == KeyEvent.ACTION_UP
        if (isMouse && event.keyCode == KeyEvent.KEYCODE_BACK) {
            // Klik kanan mouse sering dikirim Android sebagai tombol BACK
            if (down) view?.setRightClick(true) else if (up) view?.setRightClick(false)
        } else {
            if (down) view?.setKey(event.keyCode, true) else if (up) view?.setKey(event.keyCode, false)
        }
        return false // teruskan ke game / app lain
    }

    // Android 14+: event mouse global
    override fun onMotionEvent(event: MotionEvent) {
        val v = view ?: return
        if (!Prefs.isOn(this)) return
        when (event.actionMasked) {
            MotionEvent.ACTION_SCROLL -> {
                val s = event.getAxisValue(MotionEvent.AXIS_VSCROLL)
                if (s != 0f) v.flashScroll(s > 0f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.setMouseButtons(0)
            else -> v.setMouseButtons(event.buttonState)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        view?.clearAll()
    }

    override fun onDestroy() {
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(this)
        view?.let { wm.removeView(it) }
        probe?.let { wm.removeView(it) }
        view = null
        probe = null
        super.onDestroy()
    }
}
