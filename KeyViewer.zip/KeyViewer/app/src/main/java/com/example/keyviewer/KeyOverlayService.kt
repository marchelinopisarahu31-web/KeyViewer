package com.example.keyviewer

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Accessibility service: menangkap keyboard & mouse fisik secara global
 * lalu menampilkannya di overlay. Event TIDAK dikonsumsi, jadi tetap sampai ke game
 * / app mapper (Panda Mouse Pro, K2ER, dll).
 */
class KeyOverlayService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {

    private var view: KeyboardView? = null
    private var params: WindowManager.LayoutParams? = null
    private var probe: View? = null          // fallback klik mouse untuk Android < 14
    private lateinit var wm: WindowManager

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // Android 14+: terima event mouse global lewat onMotionEvent
        if (Build.VERSION.SDK_INT >= 34) {
            // SOURCE_MOUSE_RELATIVE = mouse yang "dikunci" game (mis. Minecraft)
            serviceInfo = serviceInfo.apply {
                motionEventSources = InputDevice.SOURCE_MOUSE or InputDevice.SOURCE_MOUSE_RELATIVE
            }
        }

        val v = KeyboardView(this)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // supaya tetap tampil di layar landscape penuh / area notch
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        v.onConfig = { v.post { relayout() } }
        v.applyPrefs(Prefs.sp(this))
        wm.addView(v, p)
        view = v
        params = p
        relayout()
        applyEnabled()

        if (Build.VERSION.SDK_INT < 34) addProbe()

        Prefs.sp(this).registerOnSharedPreferenceChangeListener(this)
    }

    /** View 1x1 yang menangkap "touch di luar" supaya tombol mouse terbaca di Android < 14. */
    private fun addProbe() {
        val pv = View(this)
        pv.setOnTouchListener { _, e ->
            if (e.source and InputDevice.SOURCE_MOUSE == InputDevice.SOURCE_MOUSE &&
                e.actionMasked == MotionEvent.ACTION_OUTSIDE
            ) {
                view?.flashMouse(e.buttonState) // event lepas tidak dikirim Android -> kedip
            }
            false
        }
        val lp = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(pv, lp)
        probe = pv
    }

    private fun relayout() {
        val v = view ?: return
        val p = params ?: return
        val sp = Prefs.sp(this)
        // ukuran layar nyata SAAT INI (berubah waktu portrait <-> landscape)
        val dm = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        v.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val px = sp.getInt(Prefs.POS_X, 0) / 100f
        val py = sp.getInt(Prefs.POS_Y, 92) / 100f
        p.x = ((dm.widthPixels - v.measuredWidth) * px).toInt().coerceAtLeast(0)
        p.y = ((dm.heightPixels - v.measuredHeight) * py).toInt().coerceAtLeast(0)
        wm.updateViewLayout(v, p)
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        view?.postDelayed({ relayout() }, 200)
    }

    private fun applyEnabled() {
        val on = Prefs.isOn(this)
        view?.visibility = if (on) View.VISIBLE else View.GONE
        probe?.visibility = if (on) View.VISIBLE else View.GONE
        if (!on) view?.clearAll()
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        val v = view ?: return
        v.applyPrefs(Prefs.sp(this))
        v.post { relayout() }
        applyEnabled()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // Hotkey ON/OFF: CTRL + ALT + K
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 &&
            event.keyCode == KeyEvent.KEYCODE_K && event.isCtrlPressed && event.isAltPressed
        ) {
            Prefs.setOn(this, !Prefs.isOn(this))
            return false
        }
        if (!Prefs.isOn(this)) return false

        val isMouse = event.source and InputDevice.SOURCE_MOUSE == InputDevice.SOURCE_MOUSE
        val down = event.action == KeyEvent.ACTION_DOWN
        val up = event.action == KeyEvent.ACTION_UP
        if (event.keyCode == KeyEvent.KEYCODE_BACK && (isMouse || up)) {
            // Klik kanan mouse sering dikirim Android sebagai tombol BACK.
            // Saat dilepas (UP), event kadang tidak lagi bertanda "mouse",
            // makanya UP dari BACK selalu melepas klik kanan.
            if (down) view?.setRightClick(true) else if (up) view?.setRightClick(false)
        } else {
            if (down) view?.setKey(event.keyCode, true) else if (up) view?.setKey(event.keyCode, false)
        }
        return false // teruskan ke game / app lain
    }

    // Android 14+: event mouse global
    override fun onMotionEvent(event: MotionEvent) {
        val v = view ?: return
        if (!Prefs.isOn(this)) return
        when (event.actionMasked) {
            MotionEvent.ACTION_SCROLL -> {
                val s = event.getAxisValue(MotionEvent.AXIS_VSCROLL)
                if (s != 0f) v.flashScroll(s > 0f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL,
            MotionEvent.ACTION_HOVER_EXIT -> v.setMouseButtons(0)
            // Event "lepas" sering tidak sampai ke service -> tombol otomatis lepas
            // kalau tidak ada event baru (tiap event baru memperpanjang waktunya).
            else -> if (event.buttonState != 0) v.flashMouse(event.buttonState) else v.setMouseButtons(0)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        view?.clearAll()
    }

    override fun onDestroy() {
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(this)
        view?.let { wm.removeView(it) }
        probe?.let { wm.removeView(it) }
        view = null
        probe = null
        super.onDestroy()
    }
}
