package com.example.keyviewer

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Accessibility service: menangkap tombol keyboard fisik secara global
 * dan menampilkannya di overlay (tanpa izin "tampil di atas aplikasi lain").
 */
class KeyOverlayService : AccessibilityService() {

    private var view: KeyboardView? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = KeyboardView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = 24
            y = 24
        }
        wm.addView(v, params)
        view = v
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        when (event.action) {
            KeyEvent.ACTION_DOWN -> view?.setKey(event.keyCode, true)
            KeyEvent.ACTION_UP -> view?.setKey(event.keyCode, false)
        }
        // false = tombol tetap diteruskan ke aplikasi/game di depan
        return false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        view?.clearKeys()
    }

    override fun onDestroy() {
        view?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        view = null
        super.onDestroy()
    }
}
