package com.example.keyviewer

import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Tombol ON/OFF di Quick Settings (tarik panel notifikasi → edit → tambah "KeyViewer"). */
class KeyTileService : TileService() {

    override fun onStartListening() = refresh()

    override fun onClick() {
        Prefs.setOn(this, !Prefs.isOn(this))
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val on = Prefs.isOn(this)
        tile.icon = Icon.createWithResource(this, R.drawable.ic_tile)
        tile.label = "KeyViewer"
        tile.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }
}
